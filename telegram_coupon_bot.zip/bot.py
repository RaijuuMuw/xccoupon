from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters
import random

# Купоны
COUPONS = [
    "CUPON-1234",
    "CUPON-5678",
    "CUPON-9876",
    "CUPON-4321",
]

# Состояния
user_state = {}

# /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("Я сделал покупку в ХС", callback_data="buy_xs")],
        [InlineKeyboardButton("Я сделал покупку в ПравдаКофе", callback_data="buy_pc")],
    ]
    await update.message.reply_text("Где вы совершили покупку?", reply_markup=InlineKeyboardMarkup(keyboard))

# Кнопки
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data in ["buy_xs", "buy_pc"]:
        user_state[user_id] = {"step": "wait_receipt", "brand": data}
        await query.message.reply_text("📸 Пожалуйста, прикрепите фото чека.")
    
    elif data in ["has_card", "no_card"]:
        user_state[user_id]["step"] = "wait_phone"
        await query.message.reply_text("📱 Введите номер телефона:")

# Фото чека
async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    state = user_state.get(user_id, {})
    
    if state.get("step") != "wait_receipt":
        return

    brand = state.get("brand")
    if brand == "buy_xs":
        keyboard = [
            [InlineKeyboardButton("У меня есть карта лояльности ПравдаКофе", callback_data="has_card")],
            [InlineKeyboardButton("У меня нет карты лояльности ПравдаКофе", callback_data="no_card")],
        ]
        user_state[user_id]["step"] = "wait_card"
        await update.message.reply_text("У вас есть карта лояльности ПравдаКофе?", reply_markup=InlineKeyboardMarkup(keyboard))
    else:
        user_state[user_id]["step"] = "wait_phone"
        await update.message.reply_text("📱 Введите номер телефона:")

# Телефон
async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    state = user_state.get(user_id, {})

    if state.get("step") != "wait_phone":
        return

    phone = update.message.text.strip()
    if not phone.isdigit():
        await update.message.reply_text("❗ Пожалуйста, введите корректный номер телефона.")
        return

    coupon = random.choice(COUPONS)
    await update.message.reply_text(f"🎉 Спасибо за покупку! Ваш купон: {coupon}")

    # Очистка состояния
    user_state.pop(user_id, None)

# Запуск
if __name__ == '__main__':
    app = ApplicationBuilder().token("YOUR_BOT_TOKEN").build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))

    print("Бот запущен")
    app.run_polling()
